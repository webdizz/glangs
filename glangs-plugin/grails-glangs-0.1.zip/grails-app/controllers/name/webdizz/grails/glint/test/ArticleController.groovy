package name.webdizz.grails.glint.test

class ArticleController {

    def index = { }
}
